-- plik: Main.hs
module Main(main) where  -- eksportuje tylko  main
--module Main where        -- exportuje wszystko
import qualified Stack as S
import Data.Array
import Control.Exception
import System.IO

-- Ten modu� celowo jest wzorowany na module stackTest.ml 
-- z poprzedniego wyk�adu,
-- ale wykorzystuje stos niemodyfikowalny

main = repeatTest (True, S.create())

menuItems = array (0,5) (zip [0..5] ["Stack Operations","push", "top", "pop", "isEmpty", "quit testing"])

doA :: (Monad m, Ix k) => (Array k t -> k -> m a) -> m b -> Array k t -> [k] -> m b 
doA  rep finally a (i:is) =
  do rep a i
     doA rep finally a is
doA   _  finally _   _    =  finally
          
menu :: Array Int String -> IO Int
menu opt =
  do putStr "\n\n=================================================== \n"
     putStrLn (opt ! 0)
     doA (\a i -> putStrLn ((show i)++". "++(opt ! i)))
         (putStr "\nSelect an option: " >> System.IO.hFlush stdout)
          opt (tail $ indices opt)
     choice <- getLine
     return (read choice)  

{- mo�na te� tak:
menu opt =
  do putStr "\n\n=================================================== \n"
     putStrLn (opt ! 0)
     putStrLn ((show 1)++". "++(opt ! 1))
     putStrLn ((show 2)++". "++(opt ! 2))
     putStrLn ((show 3)++". "++(opt ! 3))
     putStrLn ((show 4)++". "++(opt ! 4))
     putStrLn ((show 5)++". "++(opt ! 5))
     putStr "\nSelect an option: "
     System.IO.hFlush stdout
     choice <- getLine
     return (read choice)
-}

repeatTest :: (Bool, S.T Int) -> IO()
repeatTest (False, _) = return ()
repeatTest (True, s) =
  do choice <- menu menuItems
     case choice of
      1 -> do putStr "Stack item = "
              System.IO.hFlush stdout
              item <- getLine
              repeatTest (True, S.push (read item) s)
      2 -> do Control.Exception.catch (print $ S.top s)
                                      (\msg -> putStrLn $ "Exception: " ++ show (msg::Control.Exception.SomeException))
              repeatTest (True, s)
      3 -> do putStrLn "popped"
              repeatTest (True, S.pop s)
      4 -> do putStrLn $ "Stack is "++(if S.isEmpty s then "" else "not ")++"empty."
              repeatTest (True, s)
      5 -> repeatTest (False, s)
 
  
  
