-- plik: Stack.hs
module Stack (T, create, push, top, pop, isEmpty) where
  data T a = EmptyStack | Push a (T a) 
--           deriving (Read, Show)
  create :: () -> T a
  create() = EmptyStack
  push e s = Push e s

  top (Push e _) = e
  top EmptyStack = error "module Stack: top"

  pop (Push _ s) = s
  pop EmptyStack = EmptyStack

  isEmpty EmptyStack = True
  isEmpty _ = False
